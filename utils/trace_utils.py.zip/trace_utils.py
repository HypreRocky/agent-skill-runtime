from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence


def _normalize_cot(
    cot: Any,
    *,
    mode: str,
    steps_len: Optional[int] = None,
    documents: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    if mode == "doc_answer":
        default_title = "正在检索知识"
    else:
        default_title = "正在执行技能"

    title = default_title
    subtitle: List[str] = []

    if isinstance(cot, dict):
        candidate_title = cot.get("title")
        if isinstance(candidate_title, str) and candidate_title.strip():
            title = candidate_title.strip()
        candidate_subtitle = cot.get("subtitle")
        if isinstance(candidate_subtitle, list):
            subtitle = [str(item).strip() for item in candidate_subtitle if str(item).strip()]

    if mode == "doc_answer":
        if not subtitle:
            subtitle = [_describe_documents(documents)]
    else:
        if steps_len is not None:
            if len(subtitle) != steps_len:
                subtitle = [f"正在执行步骤{i + 1}" for i in range(steps_len)]
        elif not subtitle:
            subtitle = ["正在执行步骤1"]

    return {"title": title, "subtitle": subtitle}


def _describe_documents(documents: Optional[Sequence[str]]) -> str:
    if not documents:
        return "正在从文档中检索知识"
    names = [Path(doc).name for doc in documents if isinstance(doc, str) and doc]
    if not names:
        return "正在从文档中检索知识"
    unique = list(dict.fromkeys(names))
    if len(unique) <= 3:
        return f"正在从{'、'.join(unique)}中检索知识"
    return f"正在从{len(unique)}份文档中检索知识"
